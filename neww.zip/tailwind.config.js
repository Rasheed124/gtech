const plugin = require("tailwindcss/plugin");

module.exports = {
  content: ["./**/*.html", "./js/**/*.js"],
  // dark green -  #004437
  // grey -  #E1F3E5
  // Light green -  #00DB5E
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        primary: "#004437",
        secondary: "#E1F3E5",
        lightgreen: "#00DA5F",
        gray: {
          50: "#F9FAFB",
          100: "#F3F4F6",
          200: "#E5E7EB",
          300: "#BFC4CD",
          400: "#9CA3AF",
          500: "#6B7280",
          600: "#4B5563",
          700: "#374151",
          800: "#1F2937",
          900: "#111827",
          950: "#030712",

          // 50: "#F2F8F7",
          // 100: "#D6EEEC",
          // 200: "#ADE0DE",
          // 300: "#7DCFCB",
          // 400: "#4DBBB5",
          // 500: "#259B96", // Base Color Tone Variant
          // 600: "#197F77",
          // 700: "#125F5B",
          // 800: "#0A413F",
          // 900: "#042D2B",
          // 950: "#011514",
        },
        violet: {
          50: "#F2F8F7",
          100: "#D6EEEC",
          200: "#ADE0DE",
          300: "#7DCFCB",
          400: "#4DBBB5",
          500: "#259B96", // Base Color Tone Variant
          600: "#197F77",
          700: "#125F5B",
          800: "#0A413F",
          900: "#042D2B",
          950: "#011514",
        },
        sky: {
          // 50: "#E3F3FF",
          // 100: "#D1ECFF",
          // 200: "#B6E1FF",
          // 300: "#A0D7FF",
          // 400: "#7BC8FF",
          // 500: "#67BFFF",
          // 600: "#56B1F3",
          // 700: "#3193DA",
          // 800: "#1C71AE",
          // 900: "#124D79",
          // 950: "#0B324F",

          50: "#F2F8F7",
          100: "#D6EEEC",
          200: "#ADE0DE",
          300: "#7DCFCB",
          400: "#4DBBB5",
          500: "#259B96", // Base Color Tone Variant
          600: "#197F77",
          700: "#125F5B",
          800: "#0A413F",
          900: "#042D2B",
          950: "#011514",
        },
        green: {
          50: "#D2FFE2",
          100: "#B1FDCD",
          200: "#8BF0B0",
          300: "#67E294",
          400: "#4BD37D",
          500: "#3EC972",
          600: "#34BD68",
          700: "#239F52",
          800: "#15773A",
          900: "#0F5429",
          950: "#0A3F1E",

          // 50: "#E6FAF0",
          // 100: "#C2F3DA",
          // 200: "#97EBC1",
          // 300: "#69E0A4",
          // 400: "#3AD588",
          // 500: "#00DB5E", // Base Color
          // 600: "#00B64E",
          // 700: "#00903E",
          // 800: "#006B2E",
          // 900: "#004A1F",
          // 950: "#002A12",
        },
        red: {
          50: "#FFE8E8",
          100: "#FFD1D1",
          200: "#FFB2B2",
          300: "#FF9494",
          400: "#FF7474",
          500: "#FF5656",
          600: "#FA4949",
          700: "#E63939",
          800: "#C52727",
          900: "#941818",
          950: "#600F0F",
        },
        yellow: {
          50: "#FFF2C9",
          100: "#FFE7A0",
          200: "#FFE081",
          300: "#FFD968",
          400: "#F7CD4C",
          500: "#F0BB33",
          600: "#DFAD2B",
          700: "#BC9021",
          800: "#816316",
          900: "#4F3D0E",
          950: "#342809",
        },
        white: "#FCFFFF",
        black: "#050505",
      },

      backgroundImage: {
        "dash-bg": "url('../../images/dash-bg.png')",
        "footer-texture": "url('/img/footer-texture.png')",
      },
      fontFamily: {
        inter: ["Inter", "sans-serif"],
        Poppins: ["Poppins", "sans-serif"],
      },
      fontSize: {
        xs: ["0.75rem", { lineHeight: "1.5" }],
        sm: ["0.875rem", { lineHeight: "1.5715" }],
        base: ["1rem", { lineHeight: "1.5", letterSpacing: "-0.01em" }],
        lg: ["1.125rem", { lineHeight: "1.5", letterSpacing: "-0.01em" }],
        xl: ["1.25rem", { lineHeight: "1.5", letterSpacing: "-0.01em" }],
        "2xl": ["1.5rem", { lineHeight: "1.33", letterSpacing: "-0.01em" }],
        "3xl": ["1.88rem", { lineHeight: "1.33", letterSpacing: "-0.01em" }],
        "4xl": ["2.25rem", { lineHeight: "1.25", letterSpacing: "-0.02em" }],
        "5xl": ["3rem", { lineHeight: "1.25", letterSpacing: "-0.02em" }],
        "6xl": ["3.75rem", { lineHeight: "1.2", letterSpacing: "-0.02em" }],
      },
      screens: {
        xs: "480px",
      },
      borderWidth: {
        3: "3px",
      },
      minWidth: {
        36: "9rem",
        44: "11rem",
        56: "14rem",
        60: "15rem",
        72: "18rem",
        80: "20rem",
      },
      maxWidth: {
        "8xl": "88rem",
        "9xl": "96rem",
      },
      zIndex: {
        60: "60",
      },

      scrollbar: {
        width: {
          thin: "4px", // Custom thin scrollbar width
          normal: "8px", // Custom normal scrollbar width
        },
      },
    },
  },
  plugins: [
    // eslint-disable-next-line global-require
    require("@tailwindcss/forms"),
    require("tailwind-scrollbar"), // Add the scrollbar plugin
    // add custom variant for expanding sidebar
    plugin(({ addVariant, e }) => {
      addVariant("sidebar-expanded", ({ modifySelectors, separator }) => {
        modifySelectors(
          ({ className }) =>
            `.sidebar-expanded .${e(
              `sidebar-expanded${separator}${className}`
            )}`
        );
      });
    }),
  ],
};
